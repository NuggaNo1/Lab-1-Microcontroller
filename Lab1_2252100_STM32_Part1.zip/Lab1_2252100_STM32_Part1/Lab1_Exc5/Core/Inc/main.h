/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define RED_A_Pin GPIO_PIN_1
#define RED_A_GPIO_Port GPIOA
#define YEL_A_Pin GPIO_PIN_2
#define YEL_A_GPIO_Port GPIOA
#define GRE_A_Pin GPIO_PIN_3
#define GRE_A_GPIO_Port GPIOA
#define RED_B_Pin GPIO_PIN_4
#define RED_B_GPIO_Port GPIOA
#define YEL_B_Pin GPIO_PIN_5
#define YEL_B_GPIO_Port GPIOA
#define GRE_B_Pin GPIO_PIN_6
#define GRE_B_GPIO_Port GPIOA
#define SEGAA_Pin GPIO_PIN_7
#define SEGAA_GPIO_Port GPIOA
#define SEGBA_Pin GPIO_PIN_1
#define SEGBA_GPIO_Port GPIOB
#define SEGBB_Pin GPIO_PIN_2
#define SEGBB_GPIO_Port GPIOB
#define SEGAB_Pin GPIO_PIN_8
#define SEGAB_GPIO_Port GPIOA
#define SEGAC_Pin GPIO_PIN_9
#define SEGAC_GPIO_Port GPIOA
#define SEGAD_Pin GPIO_PIN_10
#define SEGAD_GPIO_Port GPIOA
#define SEGAE_Pin GPIO_PIN_11
#define SEGAE_GPIO_Port GPIOA
#define SEGAF_Pin GPIO_PIN_12
#define SEGAF_GPIO_Port GPIOA
#define SEGAG_Pin GPIO_PIN_13
#define SEGAG_GPIO_Port GPIOA
#define SEGBC_Pin GPIO_PIN_3
#define SEGBC_GPIO_Port GPIOB
#define SEGBD_Pin GPIO_PIN_4
#define SEGBD_GPIO_Port GPIOB
#define SEGBE_Pin GPIO_PIN_5
#define SEGBE_GPIO_Port GPIOB
#define SEGBF_Pin GPIO_PIN_6
#define SEGBF_GPIO_Port GPIOB
#define SEGBG_Pin GPIO_PIN_7
#define SEGBG_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
